import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import {
  Clock,
  Star,
  Code,
  Image as ImageIcon,
  MessageSquare,
  FileText,
  ExternalLink,
  Loader2,
  Globe,
  Eye,
  Download,
  Terminal,
  Play
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import ContentViewer from "./ContentViewer";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import { toast } from "sonner";

export default function ActivityHistory({ userEmail }) {
  const [selectedContent, setSelectedContent] = useState(null);
  
  // Fetch user's reviews
  const { data: reviews = [], isLoading: loadingReviews } = useQuery({
    queryKey: ["userReviews", userEmail],
    queryFn: () => base44.entities.Review.filter({ user_email: userEmail }, "-created_date", 10),
  });

  // Fetch user's created content
  const { data: userContent = [], isLoading: loadingContent } = useQuery({
    queryKey: ["userContent", userEmail],
    queryFn: () => base44.entities.UserContent.filter({ user_email: userEmail }, "-created_date", 10),
  });

  // Fetch user's messages
  const { data: messages = [], isLoading: loadingMessages } = useQuery({
    queryKey: ["userMessages", userEmail],
    queryFn: () => base44.entities.Message.filter({ user_email: userEmail }, "-created_date", 5),
  });

  const isLoading = loadingReviews || loadingContent || loadingMessages;
  
  const handleViewContent = async (content) => {
    try {
      // Increment view count
      await base44.entities.UserContent.update(content.id, {
        view_count: (content.view_count || 0) + 1
      });
      
      setSelectedContent(content);
    } catch (error) {
      console.error("View error:", error);
      setSelectedContent(content); // Show anyway
    }
  };
  
  const handleDownloadContent = async (content) => {
    let blob, filename;

    if (content.content_type === "website") {
      blob = new Blob([content.content_data.html], { type: "text/html" });
      filename = `${content.title.replace(/[^a-z0-9]/gi, '-')}.html`;
    } else if (content.content_type === "image") {
      window.open(content.content_data.image_url, "_blank");
      return;
    } else if (content.content_type === "code") {
      const ext = content.content_data.language || "txt";
      blob = new Blob([content.content_data.code], { type: "text/plain" });
      filename = `${content.title.replace(/[^a-z0-9]/gi, '-')}.${ext}`;
    }

    if (blob) {
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      // Increment download count
      try {
        await base44.entities.UserContent.update(content.id, {
          download_count: (content.download_count || 0) + 1
        });
      } catch (error) {
        console.error("Download count error:", error);
      }
    }
  };
  
  const handleLoadInTerminal = (content) => {
    if (content.content_type === "code") {
      // Store code in localStorage for Terminal to pick up
      localStorage.setItem('napz_load_code', content.content_data.code);
      localStorage.setItem('napz_load_language', content.content_data.language || 'javascript');
      localStorage.setItem('napz_load_title', content.title);
      localStorage.setItem('napz_load_timestamp', Date.now().toString());
      
      // Open Terminal in new tab
      window.open(createPageUrl("NapzTerminal"), '_blank');
      
      toast.success("🚀 Opening Terminal with your code!");
    } else if (content.content_type === "website") {
      // Store HTML in localStorage for Website Builder to pick up
      localStorage.setItem('napz_import_code', content.content_data.html);
      localStorage.setItem('napz_import_timestamp', Date.now().toString());
      
      // Open Website Builder in new tab
      window.open(createPageUrl("WebsiteBuilder"), '_blank');
      
      toast.success("🚀 Opening Website Builder with your code!");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 text-purple-500 animate-spin" />
      </div>
    );
  }

  const hasActivity = reviews.length > 0 || userContent.length > 0 || messages.length > 0;

  if (!hasActivity) {
    return (
      <div className="text-center py-12">
        <Clock className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
        <p className="text-gray-600 dark:text-gray-400 mb-2">
          No activity yet!
        </p>
        <p className="text-sm text-gray-500 dark:text-gray-500">
          Start creating, reviewing, or engaging with the community
        </p>
      </div>
    );
  }

  return (
    <>
      <ContentViewer
        content={selectedContent}
        onClose={() => setSelectedContent(null)}
      />
      
      <div className="space-y-6">
      {/* Reviews */}
      {reviews.length > 0 && (
        <div>
          <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-500" />
            Recent Reviews ({reviews.length})
          </h3>
          <div className="space-y-3">
            {reviews.map((review) => (
              <Link key={review.id} to={createPageUrl("Discover")}>
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4 hover:shadow-lg transition-shadow cursor-pointer group"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="font-bold text-gray-900 dark:text-white mb-1 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                        {review.tool_name}
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex gap-1">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < review.rating
                                  ? "text-yellow-500 fill-current"
                                  : "text-gray-300 dark:text-gray-600"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          {formatDistanceToNow(new Date(review.created_date), { addSuffix: true })}
                        </span>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {review.helpful_count || 0} helpful
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-700 dark:text-gray-300 line-clamp-2 mb-2">
                    {review.review_text}
                  </p>
                  <div className="flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400 group-hover:gap-2 transition-all">
                    <span>View tool</span>
                    <ExternalLink className="w-3 h-3" />
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Generated Content */}
      {userContent.length > 0 && (
        <div>
          <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-500" />
            Created Content ({userContent.length})
          </h3>
          <div className="space-y-3">
            {userContent.map((content) => {
              const getIcon = () => {
                switch (content.content_type) {
                  case "website":
                    return <Globe className="w-5 h-5 text-blue-500" />;
                  case "image":
                    return <ImageIcon className="w-5 h-5 text-purple-500" />;
                  case "code":
                    return <Code className="w-5 h-5 text-green-500" />;
                  default:
                    return <FileText className="w-5 h-5 text-gray-500" />;
                }
              };

              return (
                <motion.div
                  key={content.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4 hover:shadow-lg transition-shadow cursor-pointer group"
                >
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-1">
                      {getIcon()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-gray-900 dark:text-white mb-1 truncate">
                        {content.title}
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-3 line-clamp-2">
                        {content.description}
                      </p>
                      <div className="flex items-center gap-3 text-xs text-gray-500 dark:text-gray-400 mb-3">
                        <span className="capitalize">{content.content_type}</span>
                        <span>•</span>
                        <span>{formatDistanceToNow(new Date(content.created_date), { addSuffix: true })}</span>
                        {content.view_count > 0 && (
                          <>
                            <span>•</span>
                            <span>{content.view_count} views</span>
                          </>
                        )}
                        {content.download_count > 0 && (
                          <>
                            <span>•</span>
                            <span>{content.download_count} downloads</span>
                          </>
                        )}
                      </div>
                      <div className="flex gap-2 flex-wrap">
                        {(content.content_type === "code" || content.content_type === "website") && (
                          <Button
                            size="sm"
                            onClick={() => handleLoadInTerminal(content)}
                            className="h-8 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700 text-white"
                          >
                            {content.content_type === "code" ? (
                              <>
                                <Terminal className="w-3 h-3 mr-1" />
                                Load in Terminal
                              </>
                            ) : (
                              <>
                                <Globe className="w-3 h-3 mr-1" />
                                Load in Builder
                              </>
                            )}
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleViewContent(content)}
                          className="h-8"
                        >
                          <Eye className="w-3 h-3 mr-1" />
                          View
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDownloadContent(content)}
                          className="h-8"
                        >
                          <Download className="w-3 h-3 mr-1" />
                          Download
                        </Button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}

      {/* Community Messages */}
      {messages.length > 0 && (
        <div>
          <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-pink-500" />
            Community Posts ({messages.length})
          </h3>
          <div className="space-y-3">
            {messages.map((message) => (
              <Link key={message.id} to={createPageUrl("Community")}>
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4 hover:shadow-lg transition-shadow cursor-pointer group"
                >
                  <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
                    {message.content}
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 text-xs text-gray-500 dark:text-gray-400">
                      <span>{formatDistanceToNow(new Date(message.created_date), { addSuffix: true })}</span>
                      <span>•</span>
                      <span>{message.likes || 0} likes</span>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400 group-hover:gap-2 transition-all">
                      <span>View in community</span>
                      <ExternalLink className="w-3 h-3" />
                    </div>
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
    </>
  );
}