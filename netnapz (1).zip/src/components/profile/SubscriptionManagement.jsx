import React from "react";
import { motion } from "framer-motion";
import { Crown, Zap, TrendingUp, Calendar, CreditCard, ExternalLink, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

export default function SubscriptionManagement({ user }) {
  const isPremium = user?.subscription_tier === "premium" || user?.subscription_tier === "pro";
  const isAdmin = user?.role === "admin";

  const getTierBadge = () => {
    if (isAdmin) {
      return (
        <Badge className="bg-gradient-to-r from-yellow-500 to-orange-600 text-white border-0 flex items-center gap-1">
          <Crown className="w-3 h-3" />
          Admin - Unlimited
        </Badge>
      );
    }
    
    if (user?.subscription_tier === "pro") {
      return (
        <Badge className="bg-gradient-to-r from-orange-500 to-red-600 text-white border-0 flex items-center gap-1">
          <Zap className="w-3 h-3" />
          Pro
        </Badge>
      );
    }
    
    if (user?.subscription_tier === "premium") {
      return (
        <Badge className="bg-gradient-to-r from-purple-500 to-pink-600 text-white border-0 flex items-center gap-1">
          <Crown className="w-3 h-3" />
          Premium
        </Badge>
      );
    }
    
    return (
      <Badge variant="outline" className="border-gray-300 dark:border-gray-600">
        Free Tier
      </Badge>
    );
  };

  const getTierFeatures = () => {
    if (isAdmin) {
      return [
        "✅ Unlimited everything",
        "✅ All premium features",
        "✅ Priority support",
        "✅ Admin dashboard access"
      ];
    }
    
    if (user?.subscription_tier === "pro") {
      return [
        "✅ 300 AI image generations/month",
        "✅ 100 AI video generations/month",
        "✅ Team workspace (5 users)",
        "✅ API access",
        "✅ White-label exports",
        "✅ Premium templates",
        "✅ Advanced analytics",
        "✅ Dedicated support"
      ];
    }
    
    if (user?.subscription_tier === "premium") {
      return [
        "✅ 150 AI image generations/month",
        "✅ 50 AI video generations/month",
        "✅ No watermarks",
        "✅ Commercial license",
        "✅ Priority support",
        "✅ Early access to features"
      ];
    }
    
    return [
      "✅ Unlimited AI search",
      "✅ Unlimited code generation",
      "✅ Unlimited website builder",
      "✅ Unlimited chatbot",
      "❌ Limited images (3/day)",
      "❌ Watermarks on code",
      "❌ No video generation"
    ];
  };

  const getUsageStats = () => {
    const stats = [];
    
    if (user?.daily_usage?.images_generated !== undefined) {
      const limit = user?.subscription_tier === "pro" ? 300 : user?.subscription_tier === "premium" ? 150 : 3;
      const current = user.daily_usage.images_generated || 0;
      stats.push({
        label: "Images Generated",
        current,
        limit: isAdmin ? "∞" : limit,
        percentage: isAdmin ? 0 : (current / limit) * 100,
        color: "from-purple-500 to-pink-600"
      });
    }
    
    if (user?.daily_usage?.websites_generated !== undefined) {
      const current = user.daily_usage.websites_generated || 0;
      const limit = 2;
      stats.push({
        label: "Websites Built",
        current,
        limit: isAdmin ? "∞" : limit,
        percentage: isAdmin ? 0 : (current / limit) * 100,
        color: "from-blue-500 to-cyan-600"
      });
    }
    
    return stats;
  };

  return (
    <div className="space-y-6">
      {/* Current Plan */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-2xl p-6 border-2 border-blue-200 dark:border-blue-800"
      >
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-2xl font-black text-gray-900 dark:text-white mb-2">
              Current Plan
            </h3>
            {getTierBadge()}
          </div>
          {!isAdmin && !isPremium && (
            <Link to={createPageUrl("Pricing")}>
              <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white">
                <Crown className="w-4 h-4 mr-2" />
                Upgrade Now
              </Button>
            </Link>
          )}
        </div>

        <div className="grid md:grid-cols-2 gap-4 mb-6">
          {getTierFeatures().map((feature, index) => (
            <div
              key={index}
              className="text-sm text-gray-700 dark:text-gray-300"
            >
              {feature}
            </div>
          ))}
        </div>

        {user?.subscription_start_date && !isAdmin && (
          <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 pt-4 border-t border-gray-200 dark:border-gray-700">
            <Calendar className="w-4 h-4" />
            <span>
              Subscribed {formatDistanceToNow(new Date(user.subscription_start_date), { addSuffix: true })}
            </span>
          </div>
        )}
      </motion.div>

      {/* Usage Statistics */}
      {getUsageStats().length > 0 && (
        <div>
          <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-green-500" />
            Today's Usage
          </h3>
          <div className="space-y-4">
            {getUsageStats().map((stat, index) => (
              <div key={index} className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-bold text-gray-700 dark:text-gray-300">
                    {stat.label}
                  </span>
                  <span className="text-sm font-bold text-gray-900 dark:text-white">
                    {stat.current} / {stat.limit}
                  </span>
                </div>
                {!isAdmin && (
                  <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full bg-gradient-to-r ${stat.color} transition-all duration-500`}
                      style={{ width: `${Math.min(stat.percentage, 100)}%` }}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Upgrade CTA */}
      {!isPremium && !isAdmin && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl p-6 text-white"
        >
          <div className="flex items-start gap-4 mb-4">
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
              <Crown className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-black mb-2">
                Unlock Premium Features
              </h3>
              <p className="text-white/90 text-sm mb-4">
                Get 150 AI images/month, 50 videos/month, no watermarks, commercial license, and more!
              </p>
              <ul className="space-y-1 text-sm text-white/90 mb-4">
                <li>✨ 50x more images than free tier</li>
                <li>🎥 Video generation access</li>
                <li>💼 Commercial usage rights</li>
                <li>🚀 Priority support</li>
              </ul>
            </div>
          </div>
          <Link to={createPageUrl("Pricing")}>
            <Button className="w-full bg-white text-purple-600 hover:bg-gray-100">
              View Plans & Pricing
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </motion.div>
      )}

      {/* Manage Subscription */}
      {isPremium && !isAdmin && (
        <div className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4">
          <h4 className="font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-blue-500" />
            Manage Subscription
          </h4>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
            Manage your billing, payment methods, and subscription through Stripe Customer Portal
          </p>
          <Button
            variant="outline"
            className="w-full"
            onClick={() => window.open("https://billing.stripe.com/p/login/test_00gcO90w628M5zO000", "_blank")}
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Open Stripe Portal
          </Button>
        </div>
      )}
    </div>
  );
}