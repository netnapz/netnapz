import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Download, Code, Eye, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function ContentViewer({ content, onClose }) {
  const [viewMode, setViewMode] = useState("preview");

  if (!content) return null;

  const handleDownload = () => {
    let blob, filename, mimeType;

    if (content.content_type === "website") {
      blob = new Blob([content.content_data.html], { type: "text/html" });
      filename = `${content.title.replace(/[^a-z0-9]/gi, '-')}.html`;
      mimeType = "text/html";
    } else if (content.content_type === "image") {
      // For images, open in new tab to download
      window.open(content.content_data.image_url, "_blank");
      toast.success("Image opened in new tab!");
      return;
    } else if (content.content_type === "code") {
      const ext = content.content_data.language || "txt";
      blob = new Blob([content.content_data.code], { type: "text/plain" });
      filename = `${content.title.replace(/[^a-z0-9]/gi, '-')}.${ext}`;
      mimeType = "text/plain";
    } else if (content.content_type === "video") {
      window.open(content.content_data.video_url, "_blank");
      toast.success("Video opened in new tab!");
      return;
    }

    if (blob) {
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast.success("Downloaded successfully!");
    }
  };

  const handleCopy = () => {
    let textToCopy = "";
    
    if (content.content_type === "website") {
      textToCopy = content.content_data.html;
    } else if (content.content_type === "code") {
      textToCopy = content.content_data.code;
    }
    
    if (textToCopy) {
      navigator.clipboard.writeText(textToCopy);
      toast.success("Copied to clipboard!");
    }
  };

  const renderContent = () => {
    if (content.content_type === "website") {
      if (viewMode === "preview") {
        return (
          <iframe
            srcDoc={content.content_data.html}
            className="w-full h-full border-0 bg-white rounded-lg"
            title="Website Preview"
            sandbox="allow-scripts allow-same-origin"
          />
        );
      } else {
        return (
          <pre className="bg-gray-900 text-gray-100 p-6 rounded-lg overflow-auto text-sm h-full">
            <code>{content.content_data.html}</code>
          </pre>
        );
      }
    } else if (content.content_type === "image") {
      return (
        <div className="flex items-center justify-center h-full bg-gray-100 dark:bg-gray-800 rounded-lg">
          <img
            src={content.content_data.image_url}
            alt={content.title}
            className="max-w-full max-h-full object-contain"
          />
        </div>
      );
    } else if (content.content_type === "code") {
      return (
        <pre className="bg-gray-900 text-gray-100 p-6 rounded-lg overflow-auto text-sm h-full">
          <code className={`language-${content.content_data.language || 'javascript'}`}>
            {content.content_data.code}
          </code>
        </pre>
      );
    } else if (content.content_type === "video") {
      return (
        <div className="flex items-center justify-center h-full bg-gray-100 dark:bg-gray-800 rounded-lg">
          <video
            src={content.content_data.video_url}
            controls
            className="max-w-full max-h-full"
          />
        </div>
      );
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-6xl h-[90vh] bg-white dark:bg-gray-900 rounded-3xl shadow-2xl overflow-hidden flex flex-col"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
            <div>
              <h2 className="text-2xl font-black text-gray-900 dark:text-white mb-1">
                {content.title}
              </h2>
              <p className="text-sm text-gray-600 dark:text-gray-400 capitalize">
                {content.content_type}
              </p>
            </div>
            
            <div className="flex items-center gap-2">
              {(content.content_type === "website" || content.content_type === "code") && (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setViewMode(viewMode === "preview" ? "code" : "preview")}
                  >
                    {viewMode === "preview" ? <Code className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
                    {viewMode === "preview" ? "View Code" : "Preview"}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCopy}
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                </>
              )}
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleDownload}
              >
                <Download className="w-4 h-4 mr-2" />
                Download
              </Button>
              
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-600 dark:text-gray-400" />
              </button>
            </div>
          </div>

          {/* Content Area */}
          <div className="flex-1 overflow-hidden">
            {renderContent()}
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800">
            <div className="flex items-center justify-between text-xs text-gray-600 dark:text-gray-400">
              <div>
                {content.metadata?.model_used && (
                  <span>Model: {content.metadata.model_used}</span>
                )}
              </div>
              <div className="flex items-center gap-4">
                {content.view_count > 0 && (
                  <span>{content.view_count} views</span>
                )}
                {content.file_size && (
                  <span>{(content.file_size / 1024).toFixed(1)} KB</span>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}