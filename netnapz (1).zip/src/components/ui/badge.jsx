import React from "react";

export function Badge({ children, className = "", variant = "default", ...props }) {
  const baseStyles = "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors";
  
  const variantStyles = {
    default: "border-transparent bg-blue-600 text-white",
    secondary: "border-transparent bg-gray-600 text-white",
    destructive: "border-transparent bg-red-600 text-white",
    outline: "border-gray-300 text-gray-700 dark:border-gray-600 dark:text-gray-300",
  };
  
  const finalClassName = `${baseStyles} ${variantStyles[variant] || variantStyles.default} ${className}`;
  
  return (
    <div className={finalClassName} {...props}>
      {children}
    </div>
  );
}

export const badgeVariants = {
  default: "border-transparent bg-blue-600 text-white",
  secondary: "border-transparent bg-gray-600 text-white", 
  destructive: "border-transparent bg-red-600 text-white",
  outline: "border-gray-300 text-gray-700 dark:border-gray-600 dark:text-gray-300",
};